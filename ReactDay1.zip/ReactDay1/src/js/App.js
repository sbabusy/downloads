import React, { Component } from 'react';
import '../css/style.css';
import {Menu} from './Menu'

import { BrowserRouter, Route,Switch,Redirect } from 'react-router-dom'

import HomePage from './start/Home'
import StateApp from './propstates/StateApp'
import Textinput from './propstates/Textinput'
import ChildParentInvoke from './intercomp/ChildParentInvoke'
export const App = () => (
  <div>
    <div className="menu">
        <Menu />
    </div>

    <main className="content">
            <Switch>         
          <Route exact path='/' component={HomePage}/>  
          <Route exact path='/state' component={StateApp}/> 
          <Route exact path='/props' component={Textinput}/>         
          <Route exact path='/intercomp' component={ChildParentInvoke}/>

           <Redirect to="/" />
      </Switch>     
    </main>    
  
  </div>
)