import React from 'react'

export default class ChildParentInvoke extends React.Component{
    constructor(pros){
        super(pros);
        this.state={
            data:'Initial data...'
        }
        //best practice
        this.updateState = this.updateState.bind(this);
    };
    
    updateState(event){
        this.setState({data:event.target.value});
        console.log(event.target.value)
    }
    render(){
        return(
            <div>
                <h1 className='well text-success'>Parent Component</h1>
                <h1 className='text-danger bg-success'>{this.state.data}</h1>
                <br/>
                <h2 className='container'>Child Component</h2><br/>
                <Content myDataProp = {this.state.data}
                updateStateProp = {this.updateState}></Content>
                </div>
        );

    }
}
class Content extends React.Component{
    render(){
        return(
            <div>
                <input type="text" value={this.props.myDataProp}
                onChange = {this.props.updateStateProp}/>
                <h3>{this.props.myDataProp}</h3>
                </div>
        );
    }
}