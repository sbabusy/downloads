import React from 'react';
import {Link} from 'react-router-dom'

export const Menu = () => (
<div>
    <aside>
        <div >
            <Link to='/'>Home</Link>
            <Link to='/state'>State</Link>
            <Link to='/props'>Props and states</Link>
            <Link to='/intercomp'>Child parent</Link>
           
            </div>
     </aside>
   </div> 
  )
  
