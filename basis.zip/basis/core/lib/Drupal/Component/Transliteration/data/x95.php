<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = array(
  0x00 => 'xiao', 'suo', 'li', 'zeng', 'chu', 'guo', 'gao', 'e', 'xiu', 'cuo', 'lue', 'feng', 'xin', 'liu', 'kai', 'jian',
  0x10 => 'rui', 'ti', 'lang', 'qin', 'ju', 'a', 'qiang', 'zhe', 'nuo', 'cuo', 'mao', 'ben', 'qi', 'de', 'ke', 'kun',
  0x20 => 'chang', 'xi', 'gu', 'luo', 'chui', 'zhui', 'jin', 'zhi', 'xian', 'juan', 'huo', 'pei', 'tan', 'ding', 'jian', 'ju',
  0x30 => 'meng', 'zi', 'qie', 'ying', 'kai', 'qiang', 'si', 'e', 'cha', 'qiao', 'zhong', 'duan', 'sou', 'huang', 'huan', 'ai',
  0x40 => 'du', 'mei', 'lou', 'zi', 'fei', 'mei', 'mo', 'zhen', 'bo', 'ge', 'nie', 'tang', 'juan', 'nie', 'na', 'liu',
  0x50 => 'gao', 'bang', 'yi', 'jia', 'bin', 'rong', 'biao', 'tang', 'man', 'luo', 'beng', 'yong', 'jing', 'di', 'zu', 'xuan',
  0x60 => 'liu', 'chan', 'jue', 'liao', 'pu', 'lu', 'dui', 'lan', 'pu', 'cuan', 'qiang', 'deng', 'huo', 'lei', 'huan', 'zhuo',
  0x70 => 'lian', 'yi', 'cha', 'biao', 'la', 'chan', 'xiang', 'zhang', 'chang', 'jiu', 'ao', 'die', 'qu', 'liao', 'mi', 'zhang',
  0x80 => 'men', 'ma', 'shuan', 'shan', 'huo', 'men', 'yan', 'bi', 'han', 'bi', 'shan', 'kai', 'kang', 'beng', 'hong', 'run',
  0x90 => 'san', 'xian', 'xian', 'jian', 'min', 'xia', 'shui', 'dou', 'zha', 'nao', 'zhan', 'peng', 'xia', 'ling', 'bian', 'bi',
  0xA0 => 'run', 'ai', 'guan', 'ge', 'ge', 'fa', 'chu', 'hong', 'gui', 'min', 'se', 'kun', 'lang', 'lu', 'ting', 'sha',
  0xB0 => 'ju', 'yue', 'yue', 'chan', 'qu', 'lin', 'chang', 'shai', 'kun', 'yan', 'wen', 'yan', 'e', 'hun', 'yu', 'wen',
  0xC0 => 'xiang', 'bao', 'hong', 'qu', 'yao', 'wen', 'ban', 'an', 'wei', 'yin', 'kuo', 'que', 'lan', 'du', 'quan', 'feng',
  0xD0 => 'tian', 'nie', 'ta', 'kai', 'he', 'que', 'chuang', 'guan', 'dou', 'qi', 'kui', 'tang', 'guan', 'piao', 'kan', 'xi',
  0xE0 => 'hui', 'chan', 'pi', 'dang', 'huan', 'ta', 'wen', 'ta', 'men', 'shuan', 'shan', 'yan', 'han', 'bi', 'wen', 'chuang',
  0xF0 => 'run', 'wei', 'xian', 'hong', 'jian', 'min', 'kang', 'men', 'zha', 'nao', 'gui', 'wen', 'ta', 'min', 'lu', 'kai',
);
